using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Data.SqlClient;
using System.Data;

namespace Search
{
    //16/09/2021 John Dawinan Search Username Azure Function
    public static class SearchFunction
    {
        [FunctionName("Search")]
        public static IActionResult Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            string userName = req.Query["userName"];
            string result = "No Result";

            string connection = @"Server=citizen.manukautech.info,6305;Database=CCQ3_Team3_Project;UID=CCQ3_Team3;PWD=fBit$60002;encrypt=true;trustservercertificate=true";

            try
            {
                using (SqlConnection SQLConn = new SqlConnection(connection))
                {
                    SQLConn.Open(); // Open the Connection
                    var sqlQuery = "Select * from AspNetUsers where UserName Like '" + userName + "%'"; // Define Query
                    var sqlCommand = new SqlCommand(sqlQuery, SQLConn); // Use command for excuting query

                    if (sqlCommand.Connection.State == System.Data.ConnectionState.Open)
                    {
                        sqlCommand.Connection.Close();
                    }

                    sqlCommand.Connection.Open(); // open the connection to execute the command
                    SqlDataReader SQLReader = sqlCommand.ExecuteReader(); //Retrive the results 
                    var userLikeNames = new DataTable();// Create data table to populate the usernames
                    userLikeNames.Load(SQLReader); //load the data into data table

                    result = JsonConvert.SerializeObject(userLikeNames);

                }

            }

            catch (Exception e)
            {
                result = e.Message; // result error message to the caller
            }

            return new OkObjectResult(result);
        }
    }
}
