﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace Chat.Controllers
{
    //16/09/2021 John Dawinan controller that send userName and retrives results from the Azurefunction SearchFunction
    public class SearchUserName : Controller
    {
        [HttpPost]
        public async Task<string> UserSearch(string userName)
        {
            string azureUrl = "http://localhost:7071/api/Search";

            HttpClient client = new();
            HttpResponseMessage response = await client.GetAsync($"{azureUrl}");

            HttpContent content = response.Content;

            string data = await content.ReadAsStringAsync();

            if (data != null)
            {
                return data;
            }
            else
            {
                return " ";
            }

        }
       
    }
}
