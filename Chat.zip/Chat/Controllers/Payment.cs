﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace WebApplication.Controllers
{
    //15/09/2021 John Dawinan Payment controller 
    public class Payment : Controller
    {
      //Task that sends messageNo and calls the calculation function and get the result
        [HttpPost]
        public async Task<string> CostCalculate(string messageNo)
        {
            string azureUrl = "http://localhost:7071/api/Calculate";

            HttpClient client = new();
            HttpResponseMessage response = await client.GetAsync($"{azureUrl}");

            HttpContent content = response.Content;

            string data = await content.ReadAsStringAsync();

            if (data != null)
            {
                return data;
            }
            else
            {
                return " ";
            }

        }

        
    
    }
}
